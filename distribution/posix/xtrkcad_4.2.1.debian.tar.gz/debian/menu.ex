?package(xtrkcad):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="xtrkcad" command="/usr/bin/xtrkcad"
