#
# Regular cron jobs for the xtrkcad package
#
0 4	* * *	root	[ -x /usr/bin/xtrkcad_maintenance ] && /usr/bin/xtrkcad_maintenance
